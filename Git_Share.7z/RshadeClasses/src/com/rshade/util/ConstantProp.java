package com.rshade.util;

public class ConstantProp {

	public static final String dbPropLoc ="file:/InstituteMgmtSys/RshadeClasses/properties/DBconnection.properties";
	public static final String mailPropLoc = "file:/InstituteMgmtSys/RshadeClasses/properties/mail.properties";
	public static final String tokenPropLoc ="file:/InstituteMgmtSys/RshadeClasses/properties/tokenExpireTime.properties";

}
