package com.rshade.bean;

import java.lang.annotation.Repeatable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.SecondaryTables;
import javax.persistence.Table;

import org.hibernate.annotations.Columns;


@Entity
@Table(name="STUD_DETAILS")
@SecondaryTable(name="USER_LOGIN_DETAILS", pkJoinColumns={@PrimaryKeyJoinColumn(name = "userid", referencedColumnName="userid") })
public class Student {
	
	
	private int id;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String userid;
	private String firstname;
	private String lastname;
	private char gender;
	private String email;
	private int contact_no;
	private int alt_contact_no;
	private int emergency_no;
	private String blood_group;
	private Date dob;
	private Date doj;
	private String profile_pic;
	private String address;
	private String state;
	private String country;
	private String city;
	private int pincode;
	private String status;
	
	@Column(table="USER_LOGIN_DETAILS")
	private String role;
	
	@Column(table="USER_LOGIN_DETAILS")
	private String password;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getContact_no() {
		return contact_no;
	}
	public void setContact_no(int contact_no) {
		this.contact_no = contact_no;
	}
	public int getAlt_contact_no() {
		return alt_contact_no;
	}
	public void setAlt_contact_no(int alt_contact_no) {
		this.alt_contact_no = alt_contact_no;
	}
	public int getEmergency_no() {
		return emergency_no;
	}
	public void setEmergency_no(int emergency_no) {
		this.emergency_no = emergency_no;
	}
	public String getBlood_group() {
		return blood_group;
	}
	public void setBlood_group(String blood_group) {
		this.blood_group = blood_group;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public String getProfile_pic() {
		return profile_pic;
	}
	public void setProfile_pic(String profile_pic) {
		this.profile_pic = profile_pic;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
