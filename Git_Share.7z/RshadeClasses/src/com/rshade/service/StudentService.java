package com.rshade.service;

import com.rshade.bean.Student;

public interface StudentService {

	public int createStudent(Student student);
}
