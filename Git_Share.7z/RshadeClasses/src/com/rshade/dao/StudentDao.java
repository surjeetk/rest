package com.rshade.dao;

import com.rshade.bean.Student;

public interface StudentDao {
	
	public int createStudent(Student student);

}
