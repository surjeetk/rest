package com.test.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.test.bean.User;
import com.test.service.UserService;

@Controller
public class SpringController {
	
	private Logger logger=Logger.getLogger(SpringController.class.getName());
	@Autowired
	private UserService userservice;
	
	public SpringController(){
		System.out.println("new springController object is created...");
	}
	
	
	@RequestMapping(value="/", method=RequestMethod.GET)
	public ModelAndView loadPage(Model map,HttpSession session){
		//System.out.println("inside loadpage method");
		if(session.getAttribute("name")!=null)
			return new ModelAndView("welcome-page");
		
		logger.info("Inside load page method");
		
		return new ModelAndView("userform","user",new User());
	}
	
	@RequestMapping(value="/authUser", method=RequestMethod.POST)
	public String validateUser(@ModelAttribute User user,Model map,HttpSession session){
		System.out.println("inside validate user");
		User dbuser=userservice.validateUser(user);
		if(dbuser!=null){
			session.setAttribute("name", dbuser.getName());
		return "welcome-page";
		}
		
		map.addAttribute("Message", "User does not exist");
		map.addAttribute("color", "red");
		return "userform";
		
		
		
	}
	
	@RequestMapping(value="/registerUser", method=RequestMethod.GET)
	public String registerUserPage(Model map){
		//System.out.println("inside register method");
		//return new ModelAndView("register","user",new User());
		return "register";
	}
	
	@RequestMapping(value="/registerUser", method=RequestMethod.POST)
	public ModelAndView registerUser(HttpServletRequest request,Map<String,String> map){
		String userid=request.getParameter("userid");
		String password=request.getParameter("password");
		String confirm_password=request.getParameter("confirm_password");
		String name=request.getParameter("name");
		String emailAddress=request.getParameter("emailAddress");
		
		System.out.println("name:"+name);
		
		int id=userservice.addUser(userid, password, name,emailAddress);
		
		if(id!=0){
		map.put("Message", "User registered successfully!");
		map.put("color", "green");
		return new ModelAndView("userform","user",new User(userid,password,name,emailAddress));
		}
		
		map.put("Message", "User not registered");
		map.put("color", "red");
		return new ModelAndView("userform","user",new User(userid,password,name,emailAddress));
		
		
		}
		
	@RequestMapping(value="/logout",method=RequestMethod.GET)
	public ModelAndView logout(Model map,HttpSession session){
	//	System.out.println("inside logout method");
		session.invalidate();
		return new ModelAndView("userform","user",new User());
	}
	
	}

