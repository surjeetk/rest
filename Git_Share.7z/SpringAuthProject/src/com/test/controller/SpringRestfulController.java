package com.test.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.test.bean.User;
import com.test.service.UserService;

@RestController
@CrossOrigin
@RequestMapping(value="/service/users")
public class SpringRestfulController {

	@Autowired
	private UserService userservice;
	
	@RequestMapping(value="/",method=RequestMethod.GET)
	public List<User> getAllUsers(){
		List<User> allusers=userservice.listAllUsers();
		return allusers;
	}
	
	@RequestMapping(value="{userid}",method=RequestMethod.GET)
	public User getUser(@PathVariable String userid){
		User user=userservice.getUser(userid);
		return user;
	}
	
	@RequestMapping(value="/",method=RequestMethod.POST)
	public String addUser(@RequestBody User user){
		
		if(user.getUserid()!=null){
			System.out.println("userid:"+user.getUserid());
		int id=userservice.addUser(user.getUserid(), user.getPassword(), user.getName(), user.getEmailAddress());
		return "New user created with name:"+user.getName()+" and ID:"+id;
		}
		
		return "User not created";
	}
}
