package com.test.service;

import java.util.List;

import com.test.bean.User;

public interface UserService {
	
	public User validateUser(User user);
	
	public int addUser(String userid,String password, String name, String emailAddress);
	public List<User> listAllUsers();
	public User getUser(String userid);
	
}
