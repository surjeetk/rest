package com.test.service;

import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.test.bean.User;
import com.test.dao.UserDAO;

@Service
public class UserServiceImpl implements UserService {

	private UserDAO userdao;
	
	private JavaMailSenderImpl mailSender;
	
	public UserServiceImpl(){
		System.out.println("new Service class is created...");
	}
	
	public void setUserdao(UserDAO userdao) {
		this.userdao = userdao;
	}
	
	
	public void setMailSender(JavaMailSenderImpl mailSender) {
		this.mailSender = mailSender;
	}

	public void sendConfirmationMail(int id, String name, String emailAddress){
		MimeMessage message=this.mailSender.createMimeMessage();
		MimeMessageHelper helper= new MimeMessageHelper(message);
		
		try {
			helper.setFrom(new InternetAddress("customerCare@mywebsite.com"));
			helper.setTo(emailAddress);
			helper.setText("Welcome "+name+ " to my website .. your enrollment id is:"+id);
			helper.setSubject("Registration Successful!!");
			helper.setReplyTo("no-reply@mywebsite.com");
			this.mailSender.send(message);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public User validateUser(User user) {
		// TODO Auto-generated method stub 
		User dbuser=null;
		if(user!=null){
			 dbuser=userdao.getUser(user.getUserid());
		}
		if(dbuser!=null){
			return dbuser;
		}
		return null;
	}

	@Override
	public int addUser(String userid, String password, String name, String emailAddress) {
		// TODO Auto-generated method stub
		int id=userdao.addUser(userid,password,name, emailAddress);
		if (id!=0){
			this.sendConfirmationMail(id,name,emailAddress);
		}
		return id;
		
	}

	public List<User> listAllUsers(){
		return userdao.listUser();
	}
	
	public User getUser(String userid){
		User user=userdao.getUser(userid);
		return user;
	}
}
