package com.test.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="USER")
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="user_id")
	private String userid;
	
	private String Password;
	private String name;
	
	@Column(name="email")
	private String emailAddress;
	
	public User(String userid, String password, String name,String emailAddress) {
		this.userid=userid;
		this.Password=password;
		this.name=name;
		this.emailAddress=emailAddress;
		System.out.println("new user object is created: Parameterized contructor");
	}
	
	public User(){
		System.out.println("new user object is created: default contructor");
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public int getId() {
		return id;
	}

/*	public void setId(int id) {
		this.id = id;
	}*/
	
	
	
}
