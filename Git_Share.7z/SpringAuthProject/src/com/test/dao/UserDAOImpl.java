package com.test.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.test.bean.User;

@Repository
public class UserDAOImpl implements UserDAO{
	
	
	private static SessionFactory factory;
		
	public UserDAOImpl(){
		System.out.println("new DAO class is created..");
	}

	public  void setFactory(SessionFactory factory) {
		UserDAOImpl.factory = factory;
	}

	@Override
	public User getUser(String userid) {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		Transaction tx=null;
		try{
			tx=session.beginTransaction();
			Query query=session.createQuery("FROM User WHERE userid=:userid");
			query.setParameter("userid", userid);
			List<User> list=query.list();
			tx.commit();
			if(!list.isEmpty())
			return list.get(0);
			
		}
		catch(HibernateException e){
			if(tx!=null)tx.rollback();
			System.out.println("exception occured:"+e.getMessage());
			e.printStackTrace();
		}
		finally{
			session.close();
		}
		
		return null;
	}

	@Override
	public int addUser(String userid,String password, String name, String emailAddress) {
		// TODO Auto-generated method stub
		
		User user=new User(userid,password,name,emailAddress);
		Session session=factory.openSession();
		Transaction tx=null;
		try{
			tx=session.beginTransaction();
			int id=(Integer)session.save(user);
			tx.commit();
			return id;
		}
		catch(HibernateException e){
			if(tx!=null)tx.rollback();
			System.out.println("exception occured:"+e.getMessage());
		}
		finally{
			session.close();
		}
		
		return 0;
	}

	@Override
	public List<User> listUser() {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		Transaction tx=null;
		try{
			tx=session.beginTransaction();
			
			List<User> userlist=session.createQuery("FROM User").list();
			tx.commit();
			return userlist;
		}
		catch(HibernateException e){
			if(tx!=null)tx.rollback();
			System.out.println("exception occured:"+e.getMessage());
		}
		finally{
			session.close();
		}
		
		
		return null;
	}

	@Override
	public boolean deleteUser(String userid) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
}
