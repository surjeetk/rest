package com.test.dao;

import java.util.List;

import com.test.bean.User;

public interface UserDAO {

	public User getUser(String userid);
	
	public int addUser(String userid,String password, String name, String emailAddress);
	
	public List<User> listUser();
	
	public boolean deleteUser(String userid);
}
