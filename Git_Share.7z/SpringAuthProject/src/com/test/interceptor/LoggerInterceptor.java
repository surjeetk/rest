package com.test.interceptor;

import javax.faces.application.ResourceHandler;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class LoggerInterceptor extends HandlerInterceptorAdapter {
	
	public LoggerInterceptor(){
		System.out.println("Instantiating Logger Interceptor");
	}

	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception{
		System.out.println("Inside PreHandle method of interceptor:"+request.getLocalName());
		return super.preHandle(request, response, handler);
	}
	
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		//logger.info("After handling the request");
		System.out.println("---------Inside postHandle method of interceptor:------------"+request.getLocalName());
		
		 //  HttpServletRequest req = (HttpServletRequest) request;
		//   HttpServletResponse res = (HttpServletResponse) response;
		 //  System.out.println("under no cache filter doFilter");
		   System.out.println("Mathch:"+request.getContextPath() + ResourceHandler.RESOURCE_IDENTIFIER);
		   System.out.println("Request URI:"+request.getRequestURI());
		   if (!request.getRequestURI().startsWith(request.getContextPath() + ResourceHandler.RESOURCE_IDENTIFIER)) {                                                                                                            
		System.out.println("under if");
		   // res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Cache-Control", "no-store");
		response.setHeader("Pragma", "no-cache");
		response.setDateHeader("Expires", 0);
		   }
		super.postHandle(request, response, handler, modelAndView);
	}
	
	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		//logger.info("After rendering the view");
		System.out.println("Inside afterCompletion method of interceptor:"+request.getLocalName());
		super.afterCompletion(request, response, handler, ex);
	}
}
